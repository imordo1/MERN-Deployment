const ProductController = require('../controllers/product.controller');
 
module.exports = (app) => {


    //----Route for creating new product --------    
    app.post('/', ProductController.create);
    app.get("/all", ProductController.getAll);
    app.get("/:id", ProductController.getOne);
    app.delete("/:id", ProductController.delete);
    app.get("/:id", ProductController.getOne);
    app.put('/:id/edit', ProductController.update);
    // app.put('/all', ProductController.create);
};
