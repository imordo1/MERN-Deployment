
import './App.css';
import { Link, Route, Switch} from 'react-router-dom'
import NewProduct from './Components/NewProduct'
import ProductList from './Components/ProductList';
import OneProduct from './Components/OneProduct';
import EditProduct from './Components/EditProduct';
// import NotFound from "./views/NotFound";

function App() {
  return (
    <div className="container">
      <nav className=" d-flex col col-8 flex-column container p-3 my-3 bg-dark text-white rounded shadow">
        <h1 className="fs-1 navbar-brand mb-0 mx-auto">Product Manager</h1>
        <div className="navbar-nav justify-content-between">
          <Link
            to="/all"
            className="col col-2 btn btn-sm btn-success m-2 btn-outline"
          >
            All Products
          </Link>

          <Link
            to="/"
            className="col col-3 btn btn-sm btn-success m-2 btn-outline"
          >
            Add New Product
          </Link>
        </div>
      </nav>

      <Switch>
 
        {/* <Redirect exact from="/" to="/new" /> */}
        <Route exact path="/">
          <NewProduct />
        </Route>
        <Route exact path="/all">
          <ProductList />
        </Route>
        <Route exact path="/:id">
          <OneProduct />
        </Route>
        <Route exact path="/:id/edit">
          <EditProduct />
        </Route>
        {/* <Route component={NotFound} /> */}
      </Switch>
    </div>
  );
}

export default App;